/**
 * 
 */
/**
 * 
 */
module LabSockets {
	requires java.desktop;
}